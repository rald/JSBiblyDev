var RangeType={
  "BR":"br",
  "CV":"cr",
  "VR":"vr",
  "B":"b",
  "C":"c",
  "V":"v"
};

function Range(start,end) {
  this.start=start;
  this.end=end;
}

